<?php $__env->startSection('titulo'); ?>
    <title>Busqueda</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <!--<h2>Nombre del usuario</h2>-->
                <h2><?php echo e($users->nombre); ?></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-info" href="/mostrarUsuarios"> Mostrar Usuarios</a>
            </div>
        </div>
    </div>
    
    <table class="table table-bordered table-dark">
        <tr>
            <th>DNI</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Edad</th>
            <th>Email</th>
        </tr>
        <tr>
            <td><?php echo e($users->dni); ?></td>
            <td><?php echo e($users->nombre); ?></td>
            <td><?php echo e($users->apellido); ?></td>
            <td><?php echo e($users->edad); ?></td>
            <td><?php echo e($users->email); ?></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>