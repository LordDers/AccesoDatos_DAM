<?php $__env->startSection('titulo'); ?>
    <title>Editar Usuario</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="/editUser" method="POST">
        <?php echo e(csrf_field()); ?>

        <!--<div class="text_form"> DNI </div>-->
        <div class="form-group">
            <label for="exampleInputEmail1">DNI</label>
            <input type="text" class="form-control" id="dni" name="dni" value="<?php echo e($users->dni); ?>">
        </div>
        
        <div class="form-group">
            <label for="exampleInputEmail1">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($users->nombre); ?>">
        </div>
        
        <div class="form-group">
            <label for="exampleInputEmail1">Apellido</label>
            <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e($users->apellido); ?>">
        </div>
        
        <div class="form-group">
            <label for="exampleInputPassword1">Edad</label>
            <input type="number" class="form-control" id="edad" name="edad" value="<?php echo e($users->edad); ?>">
        </div>
        
        <div class="form-group">
            <label for="exampleInputEmail1">Email</label>
            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" value="<?php echo e($users->email); ?>">
        </div>
        
        <input name='id' value='<?php echo e($users->id); ?>' hidden/>
        <button type="submit" class="btn btn-warning">Editar</button>
        <a href="/mostrarUsuarios" class="btn btn-secondary" role="button">Mostrar Usuarios</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>