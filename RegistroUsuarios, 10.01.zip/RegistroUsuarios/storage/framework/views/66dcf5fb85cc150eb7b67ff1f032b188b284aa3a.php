<?php $__env->startSection('titulo'); ?>
    <title>Editar Usuario</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div><br />
<?php endif; ?>
    
<form action="/editUser" method="POST">
    <?php echo e(csrf_field()); ?>

    <!--<div class="text_form"> DNI </div>-->
    <div class="form-group">
        <label for="exampleInputEmail1">DNI</label>
        <?php if($errors->any()): ?>
            <input type="text" class="form-control" id="dni" name="dni" value="<?php echo e(old('dni')); ?>">
        <?php else: ?>
            <input type="text" class="form-control" id="dni" name="dni" value="<?php echo e($users->dni); ?>">
        <?php endif; ?>
    </div>
    
    <div class="form-group">
        <label for="exampleInputEmail1">Nombre</label>
        <?php if($errors->any()): ?>
            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>">
        <?php else: ?>
            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($users->nombre); ?>">
        <?php endif; ?>
    </div>
    
    <div class="form-group">
        <label for="exampleInputEmail1">Apellido</label>
        <?php if($errors->any()): ?>
            <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e(old('apellido')); ?>">
        <?php else: ?>
            <input type="text" class="form-control" id="apellido" name="apellido" value="<?php echo e($users->apellido); ?>">
        <?php endif; ?>
    </div>
    
    <div class="form-group">
        <label for="exampleInputPassword1">Edad</label>
        <?php if($errors->any()): ?>
            <input type="number" class="form-control" id="edad" name="edad" value="<?php echo e(old('edad')); ?>">
        <?php else: ?>
            <input type="number" class="form-control" id="edad" name="edad" value="<?php echo e($users->edad); ?>">
        <?php endif; ?>
    </div>
    
    <div class="form-group">
        <label for="exampleInputEmail1">Email</label>
        <?php if($errors->any()): ?>
            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp"  value="<?php echo e(old('email')); ?>">
        <?php else: ?>
            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" value="<?php echo e($users->email); ?>">
        <?php endif; ?>
    </div>
    
    <?php if($errors->any()): ?>
        <input name='id' value="<?php echo e(old('id')); ?>" hidden/>
    <?php elseif(empty($users->dni)): ?>
        <input name='id' value="-1" hidden/>
        <!--<script>window.location.href = "/";</script>-->
    <?php else: ?>
        <input name='id' value='<?php echo e($users->id); ?>' hidden/>
    <?php endif; ?>
    <button type="submit" name="submit" class="btn btn-warning">Editar</button>
    <a href="/mostrarUsuarios" class="btn btn-secondary" role="button">Mostrar Usuarios</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>