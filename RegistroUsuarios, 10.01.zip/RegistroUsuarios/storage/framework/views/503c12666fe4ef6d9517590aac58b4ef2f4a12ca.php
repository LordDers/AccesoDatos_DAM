<?php $__env->startSection('titulo'); ?>
    <title>Usuarios</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div><br />
<?php endif; ?>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong>Success!</strong> <?php echo e($message); ?>

        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong>Error!</strong> <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    
    <div>
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Usuarios</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="/registro"> Crear Usuario</a>
            </div>
        </div>
    </div>
    
    <table class="table table-bordered table-dark">
        <tr>
            <th>No</th>
            <th>DNI</th>
            <th>Nombre</th>
            <th width="280px">Operation</th>
        </tr>
        <?php ($i = 1); ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <form action='/accion' method='POST' name='varias'>
                <?php echo e(csrf_field()); ?>

                <input name='id' value='<?php echo e($usuarios->id); ?>' hidden/>
                <td><?php echo e($i++); ?></td>
                <!--<td><?php echo e($usuarios->dni); ?></td>-->
                <td><?php echo e($usuarios->dni); ?></td>
                <td><?php echo e($usuarios->nombre); ?></td>
                <td>
                  <input type="submit" class="btn btn-info" name="buscar" value="Show">
                  <input type="submit" class="btn btn-warning" name="editar" value="Edit">
                  <input type="submit" class="btn btn-danger" name="borrar" value="Delete">
                </td>
            </form>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>